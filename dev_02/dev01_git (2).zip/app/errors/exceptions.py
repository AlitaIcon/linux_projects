#!/usr/bin/env python3
#-*- coding:utf-8 -*-
# author:muji
# datetime:2019/8/5 16:34

class DatabaseException(Exception):
    pass

class RunningTestException(Exception):
    pass